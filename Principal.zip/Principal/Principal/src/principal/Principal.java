/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package principal;

/**
 *
 * @author ASUS
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try { 
        Storage storage = new Storage();
        storage.Storage("Carlos", "Villagran", "202020");
        System.out.println("/////////////////////////////////////////////////////");
        storage.StorageNuevaEntidadJuridica("Diego", "Maradona", "101010");
        System.out.println("/////////////////////////////////////////////////////");
        storage.StorageNuevaEntidadParticular("Carlitos", "Vela", "505050");
        System.out.println("/////////////////////////////////////////////////////");
        storage.StorageNuevaEntidadJuridica("Javier", "Hernandez", "606060");
        System.out.println("/////////////////////////////////////////////////////");
        storage.StorageNuevaEntidadJuridica(1, "Gonzalez", "707070");
        }
        catch (Exception e) {
            System.out.println("ERROR, DETALLES DEL ERROR: " + e);
        }
        finally {
            System.out.println("FAVOR, REPETIR PROCESO CORRECTAMENTE.");
        }
    }
}
