/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package principal;

/**
 *
 * @author ASUS
 */
public interface FactoryStorage {
    public String nuevosDatos(String nuevoNombre, String nuevoApellido, String nuevoID);
}
