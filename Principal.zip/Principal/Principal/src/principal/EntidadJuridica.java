/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

/**
 *
 * @author ASUS
 */
public class EntidadJuridica implements FactoryStorage {
    private String nuevoNombreEntidadJuridica;
    private String nuevoApellidoEntidadJuridica;
    private String nuevoIDEntidadJuridica;
    @Override
    public String nuevosDatos(String nuevoNombre, String nuevoApellido, String nuevoID) {
      this.nuevoNombreEntidadJuridica = nuevoNombre;
      this.nuevoApellidoEntidadJuridica = nuevoApellido;
      this.nuevoIDEntidadJuridica = nuevoID;
        return "Nuevo Nombre Entidad Juridica: " + this.nuevoNombreEntidadJuridica + "\n" +
                "Nuevo Apellido Entidad Juridica: " + this.nuevoApellidoEntidadJuridica + "\n" +
                "Nuevo ID Entidad Juridica: " + this.nuevoIDEntidadJuridica;
    }
    
}
