/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

/**
 *
 * @author ASUS
 */
public class Storage {
    private String nombre;
    private String apellido;
    private String ID;
    
    public void Storage(String nombre, String apellido, String ID) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.ID = ID;
        
        System.out.println("Nombre: " + this.nombre + "\n" + "Apellido: " + this.apellido + "\n" + "ID: " + this.ID);
    }
    
    
    public void StorageNuevaEntidadJuridica(String nuevoNombre, String nuevoApellido, String nuevoID) {
        FactoryStorage factoryEntidadJuridica = new EntidadJuridica();
        
        System.out.println(factoryEntidadJuridica.nuevosDatos(nuevoNombre, nuevoApellido, nuevoID));
    }
    
    public void StorageNuevaEntidadParticular(String nuevoNombre, String nuevoApellido, String nuevoID) {
        FactoryStorage factoryEntidadParticular = new EntidadParticular();
        
        System.out.println(factoryEntidadParticular.nuevosDatos(nuevoNombre, nuevoApellido, nuevoID));
    }
  
}
