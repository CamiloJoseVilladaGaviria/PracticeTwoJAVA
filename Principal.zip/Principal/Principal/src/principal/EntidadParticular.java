/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

/**
 *
 * @author ASUS
 */
public class EntidadParticular implements FactoryStorage {
    private String nuevoNombreEntidadParticular;
    private String nuevoApellidoEntidadParticular;
    private String nuevoIDEntidadParticular;
    @Override
    public String nuevosDatos(String nuevoNombre, String nuevoApellido, String nuevoID) {
      this.nuevoNombreEntidadParticular = nuevoNombre;
      this.nuevoApellidoEntidadParticular = nuevoApellido;
      this.nuevoIDEntidadParticular = nuevoID;
        return "Nuevo Nombre Entidad Particular: " + this.nuevoNombreEntidadParticular + "\n" +
                "Nuevo Apellido Entidad Particular: " + this.nuevoApellidoEntidadParticular + "\n" +
                "Nuevo ID Entidad Particular: " + this.nuevoIDEntidadParticular;
    }
}
